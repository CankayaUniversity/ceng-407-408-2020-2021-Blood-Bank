<template>
  <RouterView />
</template>

<script>
import Auth from "./pages/Auth.vue";
export default {
	components: {Auth}
}
</script>

<style>

</style>
