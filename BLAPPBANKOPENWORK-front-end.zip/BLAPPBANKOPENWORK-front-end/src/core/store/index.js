import {createStore} from "vuex";

const index = createStore({

})

export default index;