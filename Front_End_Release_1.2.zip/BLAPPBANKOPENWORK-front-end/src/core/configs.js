// Axios Config
export const AxiosConfig = {
    baseURL: 'https://jsonplaceholder.typicode.com'
}